package net.englishjet.task14;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class StrukturDetailFragment extends Fragment {

    private long id;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_workout_detail, container, false);
    }


    @Override
    public void onStart() {
        super.onStart();
        View view = getView(); // fragment can't have context, so it took from its parent
        if (view != null) {
            TextView title =  view.findViewById(R.id.textTitle);
            StrukturPemerintahan struktur = StrukturPemerintahan.PEMERINTAHANS[(int)MainActivity.indicatorId1];
            title.setText(struktur.getKabupaten()[(int) MainActivity.indicatorId2]);
            TextView description =  view.findViewById(R.id.textDescription);
            description.setText(struktur.getDescription()[(int) MainActivity.indicatorId2]);
        }
    }

    public void setId(long id) {
        this.id = id;
    }
}