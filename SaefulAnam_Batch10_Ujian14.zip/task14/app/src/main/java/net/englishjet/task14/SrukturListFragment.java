package net.englishjet.task14;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.ListFragment;

public class SrukturListFragment extends ListFragment {


    static interface Listener {
        void itemClicked(long id);
    };
    private Listener listener;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (MainActivity.indicator==false)
        {
            String[] names = new String[StrukturPemerintahan.PEMERINTAHANS.length];
            for (int i = 0; i < names.length; i++) {
                names[i] = StrukturPemerintahan.PEMERINTAHANS[i].getProvinsi();
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    inflater.getContext(), android.R.layout.simple_list_item_activated_1,
                    names);
            setListAdapter(adapter);

            return super.onCreateView(inflater, container, savedInstanceState);

        }else{

            String[] names = new String[StrukturPemerintahan.PEMERINTAHANS.length];
//            String[] names = new String[StrukturPemerintahan.PEMERINTAHANS[(int)MainActivity.indicatorId1].getKabupaten().length];
            for (int i = 0; i < names.length; i++) {
                names[i] = StrukturPemerintahan.PEMERINTAHANS[(int)MainActivity.indicatorId1].getKabupaten()[i];
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    inflater.getContext(), android.R.layout.simple_list_item_activated_1,
                    names);
            setListAdapter(adapter);
            MainActivity.indicator=true;
            return super.onCreateView(inflater, container, savedInstanceState);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.listener = (Listener)context;
    }
    @Override
    public void onListItemClick(ListView listView, View itemView, int position, long id) {
        if (listener != null) {
            MainActivity.indicatorId2=id;
            listener.itemClicked(id);
        }
    }
}