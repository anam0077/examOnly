package net.englishjet.task14;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class detailActivity extends AppCompatActivity {


    public static final String EXTRA_PEMERINTAHAN_ID = "id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        StrukturDetailFragment frag = (StrukturDetailFragment)
                getSupportFragmentManager().findFragmentById(R.id.detail_frag);
        int Id = (int) getIntent().getExtras().get(EXTRA_PEMERINTAHAN_ID);
        frag.setId(Id);
    }
}