package net.englishjet.task14;


import java.util.Arrays;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StrukturPemerintahan {


    private String provinsi;
    private String[] kabupaten;
    private String[] description;
    public static final StrukturPemerintahan[] PEMERINTAHANS = {
            new StrukturPemerintahan("Jambi", new String[]{"Kerinci", "Batanghari", "Sarolangun"},new String[]{"Nama Bupati :Adirozal Luas:3.807km2", "Nama Bupati :Muhammad Fadhil Arief Luas:5,804km2", "Nama Bupati :Cek Endra Luas:6.174km2"}),
            new StrukturPemerintahan("Aceh", new String[]{"Sabang", "Banda Aceh", "Langsa"},new String[]{"Nama Walikota :Nazaruddin Luas:153 km2", "Nama Walikota :Aminullah Usman Luas:61,36 km2", "Nama Walikota:Usman Abdullah Luas: 262 km2"}),
            new StrukturPemerintahan("Nusa Tenggara Timur", new String[]{"Alor", "Belu", "Ende"},new String[]{"Nama Bupati :Amon Djobo Luas:2,864 km2", "Nama Bupati :Agustinus Taulin Luas:1,284 km2", "Nama Bupati:Djafar H. Achmad Luas: 2,046 km2"})
    };
}


