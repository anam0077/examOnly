package net.englishjet.task14;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements SrukturListFragment.Listener{

    public static boolean indicator=false;
    public static long indicatorId1,indicatorId2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public void itemClicked(long id) {
        MainActivity.indicatorId1= id;

        if(MainActivity.indicator==true) {
            Intent intent = new Intent(this, detailActivity.class);
            intent.putExtra(detailActivity.EXTRA_PEMERINTAHAN_ID, (int) id);
            MainActivity.indicator=false;
            MainActivity.indicatorId2= id;
            startActivity(intent);
        }else{
            Intent intent = new Intent(this, MainActivity.class);
            MainActivity.indicator=true;
            startActivity(intent);
        }
    }
}